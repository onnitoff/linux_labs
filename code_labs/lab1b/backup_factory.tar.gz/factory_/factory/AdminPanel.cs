﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factory
{
    public partial class AdminPanel : Form
    {
        
        private int idCustomer; //переменная для передачи id пользователя в другие формы
        public AdminPanel()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen; //стартовая позиция начального окна
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            idCustomer = 1; // стандартный id пользователя принемаем за админский
            toolStripComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            //оформление вкладки Склад
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.View = View.Details;

            listView1.Columns.Add("№", 40);
            listView1.Columns.Add("Штрихкод", 70);
            listView1.Columns.Add("Название", 70);
            listView1.Columns.Add("Количество на складе", 130);
            listView1.Columns.Add("Количество на ТП", 110);
            listView1.Columns.Add("Дата отгрузки", 120);
            listView1.Columns.Add("Срок годности", 120);
            listView1.Columns.Add("Статус", 70);

            //оформление вкладки ТП
            listView2.GridLines = true;
            listView2.FullRowSelect = true;
            listView2.View = View.Details;

            listView2.Columns.Add("№", 40);
            listView2.Columns.Add("Штрихкод", 70);
            listView2.Columns.Add("Название", 70);
            listView2.Columns.Add("Количество", 70);
            listView2.Columns.Add("Характеристики", 100);
            listView2.Columns.Add("Цена", 60);

            //оформление вкладки База клиентов
            listView3.GridLines = true;
            listView3.FullRowSelect = true;
            listView3.View = View.Details;

            listView3.Columns.Add("№", 30);
            listView3.Columns.Add("Фамилия", 80);
            listView3.Columns.Add("Имя", 80);
            listView3.Columns.Add("Дата регистрации", 120);

            //оформление вкладки перемещения товара
            listView4.GridLines = true;
            listView4.FullRowSelect = true;
            listView4.View = View.Details;

            listView4.Columns.Add("№", 40);
            listView4.Columns.Add("Название", 70);
            listView4.Columns.Add("Штрихкод", 70);
            listView4.Columns.Add("Количество", 80);
            listView4.Columns.Add("Дата изменения", 120);
            listView4.Columns.Add("Статус", 110);

            //оформление вкладки статистики проданного товара за день
            listView5.GridLines = true;
            listView5.FullRowSelect = true;
            listView5.View = View.Details;

            listView5.Columns.Add("№", 30);
            listView5.Columns.Add("Название", 70);
            listView5.Columns.Add("Штрихкод", 180);
            listView5.Columns.Add("Количество", 80);
            listView5.Columns.Add("Время покупки", 190);
            listView5.Columns.Add("Покупатель", 120);

            //оформление вкладки статистики кол клиентов за день
            listView6.GridLines = true;
            listView6.FullRowSelect = true;
            listView6.View = View.Details;

            listView6.Columns.Add("№", 30);
            listView6.Columns.Add("Фамилия", 80);
            listView6.Columns.Add("Имя", 230);
            listView6.Columns.Add("Время покупки", 120);

            //вызов подгрузки с бд данных в клиент
            LoadStorageTable();
            LoadMPTable();
            LoadSelectCustomers();
            LoadCustomersTable();
            LoadHistoryStorageToMP();
            LoadStatOfProductsSoldPerDay();
            LoadStatCountOfCustomersPerDay();

        }

        private void toolStripButton1_Click(object sender, EventArgs e) //блок открытия формы добавления продукта на склад
        {
            InsertProductToStorage insert = new InsertProductToStorage(); 
            insert.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e) //блок открытия формы высталения товара на тп
        {
            int id = 0; //инициализация переменной
            try
            {
                id = Convert.ToInt32(listView1.SelectedItems[0].SubItems[0].Text); //id товара берется по выбранной строчке на listview
                ProductToMP productToMP = new ProductToMP(id); //открытие окна выствления товара на тп и передача в него id товара на складе
                productToMP.Show();
            }
            catch
            {
                MessageBox.Show("Выберите продукт!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e) //блок вызова формы корзины товара
        {
            int id = 0;
            try
            {
                id = Convert.ToInt32(listView2.SelectedItems[0].SubItems[0].Text);
                ProductToBag productToBag = new ProductToBag(id, idCustomer); //открытие окна корзины и передача в него id товара и id пользователя, соврешающего покупку
                productToBag.Show();
            }
            catch
            {
                MessageBox.Show("Выберите продукт!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButton6_Click(object sender, EventArgs e) //блок вызова формы информации о покупках пользователя
        {
            int id = 0;
            try
            {
                id = Convert.ToInt32(listView3.SelectedItems[0].SubItems[0].Text); //записываем id пользователя выбранного в listview
                InfoAboutBagCustomer infoAboutBagCustomer = new InfoAboutBagCustomer(id);
                infoAboutBagCustomer.Show();
            }
            catch
            {
                MessageBox.Show("Выберите пользователя!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public  void LoadStorageTable() //запрос в бд информации со storage и вывод информации в listview
        {
            try
            {
                listView1.Items.Clear();
                using (FactoryContext context = new FactoryContext()) //обращение к бд
                {
                    var select = context.SelectStorageInfo(); //вызов хранимой процедуры


                    foreach (var item in select) //перебор и запись в определенные ячейки всех элементов storage в бд
                    {
                        ListViewItem items = new ListViewItem(new string[]
                         {
                        Convert.ToString(item.Id),
                        Convert.ToString(item.Barcode),
                        Convert.ToString(item.Name),
                        Convert.ToString(item.CountOnStorage),
                        Convert.ToString(item.CountOnMP),
                        Convert.ToString(item.ShipDate),
                        Convert.ToString(item.ExpirationDate),
                        Convert.ToString(item.Status)
                         });
                        listView1.Items.Add(items);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadMPTable() // SELECT MP listview
        {
            try
            {
                listView2.Items.Clear();
                using (var context = new FactoryContext())
                {
                    var select = context.SelectMPInfo2();

                    foreach (var item in select)
                    {
                        ListViewItem items = new ListViewItem(new string[]
                            {
                                Convert.ToString(item.Id),
                                Convert.ToString(item.Barcode),
                                Convert.ToString(item.Name),
                                Convert.ToString(item.CountOnMP),
                                Convert.ToString(item.Other),
                                Convert.ToString(item.Price)
                            });
                        listView2.Items.Add(items);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadCustomersTable() //SELECT Customers listview
        {
            try
            {
                listView3.Items.Clear();
                using (var context = new FactoryContext())
                {
                    var select = context.SelectCustomersInfo();

                    foreach (var item in select)
                    {
                        ListViewItem items = new ListViewItem(new string[]
                            {
                                Convert.ToString(item.Id),
                                Convert.ToString(item.LastName),
                                Convert.ToString(item.FirstName),
                                Convert.ToString(item.RegistrationDate)
                            });
                        listView3.Items.Add(items);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadHistoryStorageToMP() //SELECT HistoryStorageToMP listview
        {
            try
            {
                listView4.Items.Clear();
                using (var context = new FactoryContext())
                {
                    var select = context.SelectHistoryStorageToMP();

                    foreach (var item in select)
                    {
                        ListViewItem items = new ListViewItem(new string[]
                            {
                                Convert.ToString(item.Id),
                                Convert.ToString(item.Name),
                                Convert.ToString(item.Barcode),
                                Convert.ToString(item.Count),
                                Convert.ToString(item.TradingDate),
                                Convert.ToString(item.Status)
                            });
                        listView4.Items.Add(items);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadStatOfProductsSoldPerDay() //SELECT Stat per day
        {
            try
            {
                listView5.Items.Clear();
                using (var context = new FactoryContext())
                {
                    var select = context.SelectStatOfProductsSoldPerDay();

                    int i = 0;
                    int count = 0;
                    foreach (var item in select)
                    {
                        i++;
                        ListViewItem items = new ListViewItem(new string[]
                            {
                                Convert.ToString(i),
                                Convert.ToString(item.Name),
                                Convert.ToString(item.Barcode),
                                Convert.ToString(item.Count),
                                Convert.ToString(item.DateOfBuy),
                                Convert.ToString(item.Customer)
                            });
                        listView5.Items.Add(items);
                        count += item.Count;
                    }
                    ListViewItem listViewItem = new ListViewItem(new string[] //подведение итогов дня
                        {
                            "",
                            "",
                            "Проданного товара за сегодня:",
                            Convert.ToString(i),
                            "Проданного единиц товара всего:",
                            Convert.ToString(count)
                        });
                    listView5.Items.Add("");
                    listView5.Items.Add(listViewItem);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadStatCountOfCustomersPerDay() //SELECT count customers per day
        {
            try
            {
                listView6.Items.Clear();
                using (var context = new FactoryContext())
                {
                    var select = context.SelectStatCountOfCustomersPerDay();

                    int i = 0;
                    foreach (var item in select)
                    {
                        i++;
                        ListViewItem items = new ListViewItem(new string[]
                            {
                                Convert.ToString(i),
                                Convert.ToString(item.LastName),
                                Convert.ToString(item.FirstName),
                                Convert.ToString(item.TimeOfBuy)
                            });
                        listView6.Items.Add(items);
                    }
                    ListViewItem listViewItem = new ListViewItem(new string[] //подвод итогов за день
                        {
                            "",
                            "",
                            "Суммарное количество клиентов за день:",
                            Convert.ToString(i)
                        });
                    listView6.Items.Add("");
                    listView6.Items.Add(listViewItem);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e) //кнопка обновить вызывает все select`ы всех listview
        {
            LoadStorageTable();
            LoadMPTable();
            LoadSelectCustomers();
            LoadCustomersTable();
            LoadHistoryStorageToMP();
            LoadStatOfProductsSoldPerDay();
            LoadStatCountOfCustomersPerDay();
        }

        private void toolStripButton7_Click(object sender, EventArgs e) //блок открытия формы добавление новых пользователей
        {
            AddingCustomers addingCustomers = new AddingCustomers();
            addingCustomers.Show();
        }

        private void LoadSelectCustomers() //SELECT customers
        {
            toolStripComboBox1.Items.Clear();
            using (var context = new FactoryContext())
            {
                try
                {
                    var select = context.SelectCustomersInfo();
                    foreach (var item in select)
                    {
                        var newString = item.LastName + ' ' + item.FirstName;
                        toolStripComboBox1.Items.AddRange(new string[]
                            {
                                 Convert.ToString(newString)
                            });
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
              //  toolStripComboBox1.SelectedIndex = 0;
            }
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e) 
        {
            idCustomer = toolStripComboBox1.SelectedIndex + 1; //запись выбранного пользователя +1 из-за того, что в бд счет с 1, а на клиенте с 0
        }

        public void UpdateTable() //кнопка обновить все listview
        {
            LoadStorageTable();
            LoadMPTable();
            LoadSelectCustomers();
            LoadCustomersTable();
            LoadHistoryStorageToMP();
            LoadStatOfProductsSoldPerDay();
            LoadStatCountOfCustomersPerDay();
        }
    }
}
