﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using factory;

namespace factory
{
    public partial class InsertProductToStorage : Form
    {
        public InsertProductToStorage()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int barCode = 0;
            int count = 0;
            DateTime dateTime = DateTime.Now;
            try
            {
                barCode = int.Parse(textBox2.Text);
                count = int.Parse(textBox3.Text);
                dateTime = DateTime.Parse(textBox4.Text);

                try //обращение к бд
                {
                    using (var context = new FactoryContext())
                    {
                        context.InsertProductsAndInsertToStorage2(textBox1.Text, barCode, dateTime, count);
                    }

                    MessageBox.Show("Товар успешно добавлен");

                    //AdminPanel adminPanel1 = new AdminPanel();
                    //adminPanel1.LoadStorageTable();
                    
                    
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            AdminPanel adminPanel = new AdminPanel(); //две строки не рабочие, вопрос почему не происходит обновление таблицы storage после вызова метода с этой формы
            adminPanel.LoadStorageTable();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
