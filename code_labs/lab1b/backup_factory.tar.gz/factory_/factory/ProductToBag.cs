﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factory
{
    public partial class ProductToBag : Form
    {
        private int id;
        private int maxCountProduct;
        public int idCustomer;
        public ProductToBag(int id, int idCustomer)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.id = id;
            this.idCustomer = idCustomer;
            textBox1.ReadOnly = true; //запрет на редактирование textbox. в которые записывается информация из бд
            textBox4.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox5.ReadOnly = true;

        }

        private void ProductToBag_Load(object sender, EventArgs e) //обращение к бд
        {
            try
            {
                using (var context = new FactoryContext())
                {
                    var select = context.SelectByIdFromMP2(id); //выборка иноформации о продукте по id товара на тп
                    foreach (var item in select)
                    {
                        textBox1.Text = item.Name;
                        textBox4.Text = item.ExpirationDate.ToString();
                        textBox5.Text = item.Price.ToString();
                        maxCountProduct = item.Count;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            trackBar1.Minimum = 1; //минимальное значение трэкбара 
            trackBar1.Maximum = maxCountProduct; //максимальное значение соответствует значению товара выставленного на тп
            textBox2.Text = "1";
        }

        private void trackBar1_Scroll(object sender, EventArgs e) //событие изменения значения трэкбара
        {
            textBox2.Text = trackBar1.Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e) //блок обращения к бд
        {
            try
            {
                using (var context = new FactoryContext())
                {
                    context.AddingToHistoryCustomersBuy(id, trackBar1.Value, idCustomer); //добавление купленного товара в историю покупок
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            try
            {
                using (var context = new FactoryContext())
                {
                    context.BuyingDeleteOnMPAndOnStorage(id, trackBar1.Value, idCustomer); // хранимая процедура --логика выполнение покупки в магазине, см комментарии в базе
                }

                MessageBox.Show("Товар куплен!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
