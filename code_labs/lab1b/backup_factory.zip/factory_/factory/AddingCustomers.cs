﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factory
{
    //добавление пользователей
    public partial class AddingCustomers : Form
    {
        public AddingCustomers()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen; //позиционирование окна по центру
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == null || textBox2.Text == null) //проверка на пустоту textbox
            {
                MessageBox.Show("Введите данные!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error); //вывод сообщения ошибки
            }
            else
            {
                try //блок обращения клиента к бд
                {
                    using (var context = new FactoryContext())
                    {
                        context.InsertCustomers(textBox2.Text, textBox1.Text); //вызов хранимой процедуры
                    }

                    MessageBox.Show("Пользователь успешно добавлен!");
                    this.Close(); //закрыте формы
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
