﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factory
{
    public partial class InfoAboutBagCustomer : Form
    {
        private int id;
        public InfoAboutBagCustomer(int id)
        {
            InitializeComponent();
            this.id = id; //id пользователя
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void InfoAboutBagCustomer_Load(object sender, EventArgs e)
        {
            //оформление информации о покупках
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.View = View.Details;

            listView1.Columns.Add("№", 30);
            listView1.Columns.Add("Штрихкод", 70);
            listView1.Columns.Add("Название", 70);
            listView1.Columns.Add("Количество", 70);
            listView1.Columns.Add("Дата покупки", 120);
            listView1.Columns.Add("Стоимость", 70);
            listView1.Columns.Add("Характеристики", 100);

            using (var context = new FactoryContext()) //обращение к бд
            {
                var select = context.SelectBagCustomersInfo(id);

                foreach (var item in select)
                {
                    ListViewItem items = new ListViewItem(new string[]
                     {
                        Convert.ToString(item.Id),
                        Convert.ToString(item.Barcode),
                        Convert.ToString(item.Name),
                        Convert.ToString(item.Count),
                        Convert.ToString(item.DateOfBuy),
                        Convert.ToString(item.Price),
                        Convert.ToString(item.Other)
                     });
                    listView1.Items.Add(items);
                }
            }
        }
    }
}
