﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace factory
{
    public partial class ProductToMP : Form
    {
        private int id;
        private int maxCountProduct;
        public ProductToMP(int id)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.id = id;
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox6.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal priceProduct = 0;

            try
            {
                priceProduct = decimal.Parse(textBox5.Text);

                try
                {
                    using (var context = new FactoryContext())
                    {
                        context.PutProductsToMP(id, trackBar1.Value, priceProduct, textBox3.Text);
                    }

                    MessageBox.Show("Товар успешно выставлен на ТП");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            AdminPanel adminPanel = new AdminPanel(); //обновление admin формы не работает, разобраться почему!!!!
            adminPanel.LoadStorageTable();
            adminPanel.LoadMPTable();


            
        }

        private void ProductToMP_Load(object sender, EventArgs e)
        {
            try
            {
                using (var context = new FactoryContext())
                {
                   var select = context.SelectByIdFromStorage2(id);
                    foreach (var item in select)
                    {
                        textBox1.Text = item.Name;
                        textBox2.Text = item.Barcode.ToString();
                        textBox4.Text = item.ExpirationDate.ToString();
                        maxCountProduct = item.CountOnStorage;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            trackBar1.Minimum = 1;
            trackBar1.Maximum = maxCountProduct;
            textBox6.Text = "1";


        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox6.Text = trackBar1.Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
